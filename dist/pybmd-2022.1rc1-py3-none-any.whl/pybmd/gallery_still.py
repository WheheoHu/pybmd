class GalleryStill():
    """docstring for GalleryStill."""
    def __init__(self, gallery_still):
        self.gallery_still = gallery_still

    