class GalleryStill():
    """docstring for GalleryStill."""
    def __init__(self, gallerystill):
        self.gallerystill = gallerystill

    