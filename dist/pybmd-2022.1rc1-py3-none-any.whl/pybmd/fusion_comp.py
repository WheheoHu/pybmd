class FusionComp():
    """docstring for FusionComp."""
    def __init__(self, fusion_comp):
        self.fusion_comp = fusion_comp
        
    

    