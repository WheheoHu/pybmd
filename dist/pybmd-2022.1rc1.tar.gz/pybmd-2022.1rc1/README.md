# PyBMD
(python libery for Davinci Resolve(Repack))

